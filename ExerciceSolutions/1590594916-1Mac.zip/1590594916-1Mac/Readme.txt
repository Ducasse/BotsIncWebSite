I really hope that you will enjoy this book and have fun with your kids. 
Feel free to share your experiences with me ducasse@iam.unibe.ch

The directory contains some possible solutions of the experiments I proposed, I strongly encourage you to play and experiment with the environment to create your own problems and solution. 

24 August 2005 - St�phane Ducasse




Here is a list of fixes due to typos.

Chapter 16 p 192, 

goldenRectangle: widthSize atLevel: n 
   "Draw n + 1 golden rectangles whose bigger one is of widthSize width"

   | currentRectangleWidth |
    currentRectangleWidth := widthSize.
    self goldenRectangle: currentRectangleWidth.
    n timesRepeat:
            [ self parallelWidthSegment: currentRectangleWidth.
            self turnLeft: 90.
            currentRectangleWidth := currentRectangleWidth * (((1 + 5 sqrt) / 2) - 1)]
            
Chapter 16 page 193, 
currentRectangleWidth := currentRectangleWidth * (((1 + 5 sqrt) /2 -1)            


p 223

In figure 19-2

[ self center y > 100 ]
	whileTrue: [ self go: 10 ]
	
	
	
Also in Chapter 17 on page 205, I found one minor typo - the text in the second line of the first paragragh does not match Script 17-8.  The text in the second line of the first paragragh should read Transcript show: ' treadLength after := ', treadLenth asString ; cr.
Note however that this does not have an impact on the execution. 